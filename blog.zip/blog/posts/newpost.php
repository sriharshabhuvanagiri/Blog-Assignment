<?php

// 



if(isset($_POST['submit'])) {

	$postTitle=$_POST['postTitle'];
	$postDesc=$_POST['postDesc'];
	$postTag=$_POST['postTag'];

	include("../db/dbconnect.php");
	$date = date('Y-m-d H:i:s');	
	/* CHECK if same user or email exists or not ? */
	$query="INSERT INTO posts (postTitle , postDesc , postTag , postTime )
			VALUES ('$postTitle' , '$postDesc' , '$postTag' , '$date' ) ";
	mysqli_query($conn , $query);

	printf("Successfully posted your post\n");
	header("location:posts.php");

}

/* * * * * POST Form * * * * */
else {
	/*
	echo "
		<form action='newpost.php' method='POST' >
			Title : <input type='text' name='title'></br>
			Description : <input type='text' name='description'></br>
			Tags : <input type='text' name='tag'></br>
			<input type='submit' name='submit' value='Publish'></br>
		</form>
	";*/

	include("../include/frame_newpost.php");

}


?>
