<?php
	include_once("bootstrap_cdn.php");
?>

<!-- POSTS -->

<div class="container">
		<div class="row">
			<div class="col-md-9 col-md-offset-1">

			<div class="panel panel-default">
				<!-- TITLE -->
		  		<div class="panel-heading">
		    		<h3 class="panel-title">
		    			<a href=<?php echo "post.php?id="; echo $id; ?> ><?php echo $title; ?></a>
		    		</h3>
		  		</div>

		  		<!-- 	CONTENT -->
		  		<div class="panel-body">
						<?php
							echo $desc;
		    		?>
		  		</div>

		  		<!-- FOOTER-->
		  		<div class="panel-footer">
					<span class="col-sm-2">
							<span class="glyphicon glyphicon-tag" aria-hidden="true"></span>
			  			<a href=<?php echo "post.php?tags="; echo $tags; ?> >
									<?php echo $tags;?>
			  			</a>
					</span>
						<!-- views -->

						<span class="col-sm-3">

							<?php
								 if(isset($views)) {
									 echo "<span class='glyphicon glyphicon-eye-open' aria-hidden='true'></span>"." ".$views;
								 }
							?>
						</span>

						<!-- time -->
		  			<span class="label label-default">
							<span class="glyphicon glyphicon-time" aria-hidden="true"></span> <?php echo $time ?>
						</span>


			  			<?php
			  				$delete_post_link='../posts/delete_post.php?postid='.$id;
						?>

		  		</div>

			<!-- comments -->
			<?php
					if(isset($_REQUEST['id'])) {
							include("../posts/comments.php");
							// if(isset($_SESSION['username']))
									include("../include/commentform.php");
					}
			?>

			</div>
				<!-- end of panel -->
		</div>

		</div>
</div>
