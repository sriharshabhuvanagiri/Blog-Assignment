<div class="panel-footer">
      <span>

              <?php echo $comment['commentDesc']; ?>

      </span>

      <span>
          <span class="pull-right"><i><?php echo $comment['commentTime']; ?></i></span>
      </span>
</div>
